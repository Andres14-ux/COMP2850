package com.example.marvelapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
