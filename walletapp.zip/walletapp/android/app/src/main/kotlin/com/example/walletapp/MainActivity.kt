package com.example.walletapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
