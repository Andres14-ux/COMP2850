package com.example.lista_compras

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
