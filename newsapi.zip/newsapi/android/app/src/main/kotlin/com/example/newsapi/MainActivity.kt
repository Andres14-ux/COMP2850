package com.example.newsapi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
