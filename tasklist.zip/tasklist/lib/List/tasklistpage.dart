import 'package:flutter/material.dart';

class Task {
final String title;
 bool done;
final String description;

 Task({required this.title, required this.done, required
this.description});
}