package com.example.apiapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
